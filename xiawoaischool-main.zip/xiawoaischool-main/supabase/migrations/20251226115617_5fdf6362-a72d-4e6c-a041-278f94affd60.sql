-- Make the submissions bucket public so teachers can view student files
UPDATE storage.buckets 
SET public = true 
WHERE id = 'submissions';