-- Fix security issue: Require authentication for profiles table
-- This prevents unauthenticated public access while keeping all existing policies intact
CREATE POLICY "Require authentication for profiles"
ON public.profiles
FOR SELECT
USING (auth.uid() IS NOT NULL);

-- Fix security issue: Require authentication for exam_results table
-- This prevents unauthenticated public access while keeping all existing policies intact
CREATE POLICY "Require authentication for exam_results"
ON public.exam_results
FOR SELECT
USING (auth.uid() IS NOT NULL);