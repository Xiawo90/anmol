-- Allow students to view profiles of teachers assigned to their class (for messaging)
CREATE POLICY "Students can view teacher profiles for messaging"
ON public.profiles
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.student_enrollments se
    JOIN public.teacher_assignments ta ON ta.class_id = se.class_id
    WHERE se.student_id = auth.uid()
    AND ta.teacher_id = profiles.user_id
  )
);