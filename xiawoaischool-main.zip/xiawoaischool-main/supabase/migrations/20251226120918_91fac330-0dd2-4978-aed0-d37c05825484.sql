-- Allow teachers to view all profiles (needed to see student names)
CREATE POLICY "Teachers can view all profiles" 
ON public.profiles 
FOR SELECT 
USING (is_teacher(auth.uid()) AND is_approved(auth.uid()));