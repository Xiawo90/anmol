-- Allow unauthenticated users to view active classes for signup
CREATE POLICY "Public can view active classes for enrollment" 
ON public.classes 
FOR SELECT 
USING (status = 'active' AND allow_student_enrollment = true);