-- Create fee_payment_receipts table
CREATE TABLE public.fee_payment_receipts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fee_record_id UUID REFERENCES public.fee_records(id) ON DELETE CASCADE,
  student_id UUID NOT NULL,
  parent_id UUID NOT NULL,
  receipt_image_url TEXT NOT NULL,
  amount_paid NUMERIC,
  payment_date DATE DEFAULT CURRENT_DATE,
  notes TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'verified', 'rejected')),
  admin_remarks TEXT,
  reviewed_by UUID,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.fee_payment_receipts ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Parents can upload own receipts"
ON public.fee_payment_receipts FOR INSERT
WITH CHECK (auth.uid() = parent_id);

CREATE POLICY "Parents can view own receipts"
ON public.fee_payment_receipts FOR SELECT
USING (auth.uid() = parent_id);

CREATE POLICY "Admins can manage all receipts"
ON public.fee_payment_receipts FOR ALL
USING (is_admin(auth.uid()));

-- Create storage bucket for fee receipts
INSERT INTO storage.buckets (id, name, public) VALUES ('fee-receipts', 'fee-receipts', false);

-- Storage policies
CREATE POLICY "Parents can upload fee receipts"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'fee-receipts' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Parents can view own fee receipts"
ON storage.objects FOR SELECT
USING (bucket_id = 'fee-receipts' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Admins can view all fee receipts"
ON storage.objects FOR SELECT
USING (bucket_id = 'fee-receipts' AND is_admin(auth.uid()));

-- Trigger for updated_at
CREATE TRIGGER update_fee_payment_receipts_updated_at
BEFORE UPDATE ON public.fee_payment_receipts
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();