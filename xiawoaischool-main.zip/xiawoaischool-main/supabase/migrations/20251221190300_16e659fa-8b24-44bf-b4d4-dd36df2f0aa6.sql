-- Create study-materials storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('study-materials', 'study-materials', true)
ON CONFLICT (id) DO NOTHING;

-- RLS policy: Teachers can upload study materials
CREATE POLICY "Teachers can upload study materials"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'study-materials' 
  AND auth.role() = 'authenticated'
  AND public.is_teacher(auth.uid())
  AND public.is_approved(auth.uid())
);

-- RLS policy: Anyone can view study materials (public bucket)
CREATE POLICY "Anyone can view study materials"
ON storage.objects FOR SELECT
USING (bucket_id = 'study-materials');

-- RLS policy: Teachers can delete own materials
CREATE POLICY "Teachers can delete own study materials"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'study-materials' 
  AND auth.uid()::text = (storage.foldername(name))[1]
  AND public.is_teacher(auth.uid())
);

-- RLS policy: Teachers can update own materials
CREATE POLICY "Teachers can update own study materials"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'study-materials' 
  AND auth.uid()::text = (storage.foldername(name))[1]
  AND public.is_teacher(auth.uid())
);