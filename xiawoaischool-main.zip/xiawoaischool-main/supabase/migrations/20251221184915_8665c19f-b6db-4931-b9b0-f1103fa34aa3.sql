-- Add status and allow_student_enrollment fields to classes table
ALTER TABLE public.classes 
ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
ADD COLUMN IF NOT EXISTS allow_student_enrollment boolean NOT NULL DEFAULT true;

-- Create index for efficient filtering
CREATE INDEX IF NOT EXISTS idx_classes_enrollment ON public.classes (status, allow_student_enrollment);