-- Create storage buckets for assignments and submissions
INSERT INTO storage.buckets (id, name, public)
VALUES 
  ('assignments', 'assignments', true),
  ('submissions', 'submissions', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for assignments bucket (teachers can upload, anyone can view)
CREATE POLICY "Teachers can upload assignment files"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'assignments' 
  AND public.is_teacher(auth.uid()) 
  AND public.is_approved(auth.uid())
);

CREATE POLICY "Authenticated users can view assignment files"
ON storage.objects FOR SELECT
USING (bucket_id = 'assignments');

CREATE POLICY "Teachers can update own assignment files"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'assignments' 
  AND public.is_teacher(auth.uid()) 
  AND public.is_approved(auth.uid())
);

CREATE POLICY "Teachers can delete own assignment files"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'assignments' 
  AND public.is_teacher(auth.uid()) 
  AND public.is_approved(auth.uid())
);

-- Storage policies for submissions bucket (students can upload their own, teachers can view)
CREATE POLICY "Students can upload submission files"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'submissions' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Students can view own submission files"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'submissions' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Teachers can view all submission files"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'submissions' 
  AND public.is_teacher(auth.uid())
);

CREATE POLICY "Admins can view all submission files"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'submissions' 
  AND public.is_admin(auth.uid())
);

-- Add attachment_urls column to homework table for teacher file uploads
ALTER TABLE public.homework ADD COLUMN IF NOT EXISTS attachment_urls TEXT[] DEFAULT '{}';

-- Add location field to events table
ALTER TABLE public.events ADD COLUMN IF NOT EXISTS location TEXT;

-- Add target_class_id to events for class-specific events
ALTER TABLE public.events ADD COLUMN IF NOT EXISTS target_class_id UUID REFERENCES public.classes(id);

-- Update events RLS to allow teachers to create events for their classes
CREATE POLICY "Teachers can create events for their classes"
ON public.events FOR INSERT
WITH CHECK (
  public.is_teacher(auth.uid()) 
  AND public.is_approved(auth.uid())
  AND target_class_id IS NOT NULL
);

CREATE POLICY "Teachers can update events they created"
ON public.events FOR UPDATE
USING (
  public.is_teacher(auth.uid()) 
  AND public.is_approved(auth.uid())
  AND created_by = auth.uid()
);

CREATE POLICY "Teachers can delete events they created"
ON public.events FOR DELETE
USING (
  public.is_teacher(auth.uid()) 
  AND public.is_approved(auth.uid())
  AND created_by = auth.uid()
);