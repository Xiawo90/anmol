-- Add RLS policy for teachers to view parent profiles for messaging
CREATE POLICY "Teachers can view parent profiles for messaging"
ON public.profiles
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.parent_students ps
    JOIN public.student_enrollments se ON se.student_id = ps.student_id
    JOIN public.teacher_assignments ta ON ta.class_id = se.class_id
    WHERE ta.teacher_id = auth.uid()
    AND ps.parent_id = profiles.user_id
  )
);

-- Add RLS policy for parents to view teacher profiles for messaging
CREATE POLICY "Parents can view teacher profiles for messaging"
ON public.profiles
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.parent_students ps
    JOIN public.student_enrollments se ON se.student_id = ps.student_id
    JOIN public.teacher_assignments ta ON ta.class_id = se.class_id
    WHERE ps.parent_id = auth.uid()
    AND ta.teacher_id = profiles.user_id
  )
);