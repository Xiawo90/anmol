-- Add RLS policy for parents to view their linked children's profiles
CREATE POLICY "Parents can view children profiles"
ON public.profiles
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.parent_students
    WHERE parent_students.parent_id = auth.uid()
    AND parent_students.student_id = profiles.user_id
  )
);

-- Add RLS policy for parents to view their linked children's enrollments
CREATE POLICY "Parents can view children enrollments"
ON public.student_enrollments
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.parent_students
    WHERE parent_students.parent_id = auth.uid()
    AND parent_students.student_id = student_enrollments.student_id
  )
);

-- Add RLS policy for parents to view their linked children's attendance
CREATE POLICY "Parents can view children attendance"
ON public.attendance
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.parent_students
    WHERE parent_students.parent_id = auth.uid()
    AND parent_students.student_id = attendance.student_id
  )
);

-- Add RLS policy for parents to view their linked children's exam results
CREATE POLICY "Parents can view children results"
ON public.exam_results
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.parent_students
    WHERE parent_students.parent_id = auth.uid()
    AND parent_students.student_id = exam_results.student_id
  )
);

-- Add RLS policy for parents to view their linked children's fee records
CREATE POLICY "Parents can view children fees"
ON public.fee_records
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.parent_students
    WHERE parent_students.parent_id = auth.uid()
    AND parent_students.student_id = fee_records.student_id
  )
);

-- Add RLS policy for parents to view their linked children's homework submissions
CREATE POLICY "Parents can view children submissions"
ON public.homework_submissions
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.parent_students
    WHERE parent_students.parent_id = auth.uid()
    AND parent_students.student_id = homework_submissions.student_id
  )
);