import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { Plus, Trash2, Clock, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface TimetableEntry {
  id: string;
  class_id: string;
  section_id: string | null;
  subject_id: string;
  teacher_id: string | null;
  day_of_week: number;
  start_time: string;
  end_time: string;
  class_name?: string;
  section_name?: string;
  subject_name?: string;
  teacher_name?: string;
}

interface Class {
  id: string;
  name: string;
}

interface Section {
  id: string;
  name: string;
  class_id: string;
}

interface Subject {
  id: string;
  name: string;
}

interface Teacher {
  user_id: string;
  full_name: string;
}

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const SCHOOL_DAYS = [1, 2, 3, 4, 5]; // Monday to Friday

export default function TimetableManagement() {
  const [entries, setEntries] = useState<TimetableEntry[]>([]);
  const [classes, setClasses] = useState<Class[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedClass, setSelectedClass] = useState<string>('all');
  
  const [formData, setFormData] = useState({
    class_id: '',
    section_id: '',
    subject_id: '',
    teacher_id: '',
    day_of_week: '',
    start_time: '',
    end_time: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    
    // Fetch all required data in parallel
    const [classesRes, sectionsRes, subjectsRes, teachersRes, entriesRes] = await Promise.all([
      supabase.from('classes').select('id, name').order('name'),
      supabase.from('sections').select('id, name, class_id').order('name'),
      supabase.from('subjects').select('id, name').order('name'),
      supabase.from('profiles').select('user_id, full_name')
        .in('user_id', (await supabase.from('user_roles').select('user_id').eq('role', 'teacher')).data?.map(r => r.user_id) || []),
      supabase.from('timetable').select('*').order('day_of_week').order('start_time'),
    ]);

    setClasses(classesRes.data || []);
    setSections(sectionsRes.data || []);
    setSubjects(subjectsRes.data || []);
    setTeachers(teachersRes.data || []);

    // Map entries with names
    const entriesWithNames = (entriesRes.data || []).map(entry => ({
      ...entry,
      class_name: classesRes.data?.find(c => c.id === entry.class_id)?.name || 'Unknown',
      section_name: sectionsRes.data?.find(s => s.id === entry.section_id)?.name || null,
      subject_name: subjectsRes.data?.find(s => s.id === entry.subject_id)?.name || 'Unknown',
      teacher_name: teachersRes.data?.find(t => t.user_id === entry.teacher_id)?.full_name || null,
    }));

    setEntries(entriesWithNames);
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.class_id || !formData.subject_id || !formData.day_of_week || !formData.start_time || !formData.end_time) {
      toast.error('Please fill all required fields');
      return;
    }

    try {
      const { error } = await supabase.from('timetable').insert({
        class_id: formData.class_id,
        section_id: formData.section_id || null,
        subject_id: formData.subject_id,
        teacher_id: formData.teacher_id || null,
        day_of_week: parseInt(formData.day_of_week),
        start_time: formData.start_time,
        end_time: formData.end_time,
      });

      if (error) throw error;

      toast.success('Timetable entry created');
      setIsDialogOpen(false);
      setFormData({
        class_id: '',
        section_id: '',
        subject_id: '',
        teacher_id: '',
        day_of_week: '',
        start_time: '',
        end_time: '',
      });
      fetchData();
    } catch (error) {
      console.error('Error creating entry:', error);
      toast.error('Failed to create timetable entry');
    }
  };

  const deleteEntry = async (id: string) => {
    if (!confirm('Delete this timetable entry?')) return;

    try {
      const { error } = await supabase.from('timetable').delete().eq('id', id);
      if (error) throw error;
      toast.success('Entry deleted');
      fetchData();
    } catch (error) {
      console.error('Error deleting entry:', error);
      toast.error('Failed to delete entry');
    }
  };

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    return `${hour12}:${minutes} ${ampm}`;
  };

  const filteredSections = sections.filter(s => s.class_id === formData.class_id);
  
  const filteredEntries = selectedClass === 'all' 
    ? entries 
    : entries.filter(e => e.class_id === selectedClass);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-heading font-bold">Timetable Management</h1>
            <p className="text-muted-foreground">Create and manage class timetables</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Entry
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add Timetable Entry</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label>Class *</Label>
                  <Select
                    value={formData.class_id}
                    onValueChange={(value) => setFormData({ ...formData, class_id: value, section_id: '' })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select class" />
                    </SelectTrigger>
                    <SelectContent>
                      {classes.map((c) => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {filteredSections.length > 0 && (
                  <div>
                    <Label>Section (Optional)</Label>
                    <Select
                      value={formData.section_id || 'none'}
                      onValueChange={(value) => setFormData({ ...formData, section_id: value === 'none' ? '' : value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select section" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">All Sections</SelectItem>
                        {filteredSections.map((s) => (
                          <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div>
                  <Label>Subject *</Label>
                  <Select
                    value={formData.subject_id}
                    onValueChange={(value) => setFormData({ ...formData, subject_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select subject" />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects.map((s) => (
                        <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Teacher (Optional)</Label>
                  <Select
                    value={formData.teacher_id || 'none'}
                    onValueChange={(value) => setFormData({ ...formData, teacher_id: value === 'none' ? '' : value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select teacher" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No teacher assigned</SelectItem>
                      {teachers.map((t) => (
                        <SelectItem key={t.user_id} value={t.user_id}>{t.full_name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Day *</Label>
                  <Select
                    value={formData.day_of_week}
                    onValueChange={(value) => setFormData({ ...formData, day_of_week: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select day" />
                    </SelectTrigger>
                    <SelectContent>
                      {SCHOOL_DAYS.map((day) => (
                        <SelectItem key={day} value={day.toString()}>{DAYS[day]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Start Time *</Label>
                    <Input
                      type="time"
                      value={formData.start_time}
                      onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label>End Time *</Label>
                    <Input
                      type="time"
                      value={formData.end_time}
                      onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <Button type="submit" className="w-full">
                  Add Entry
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filter */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Filter by Class</CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="All Classes" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                {classes.map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* Timetable Entries */}
        <Card>
          <CardHeader>
            <CardTitle>Timetable Entries</CardTitle>
            <CardDescription>{filteredEntries.length} entries</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-8 text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin mr-2" />
                Loading...
              </div>
            ) : filteredEntries.length === 0 ? (
              <div className="text-center py-8">
                <Clock className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No timetable entries yet.</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Day</TableHead>
                    <TableHead>Time</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Section</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Teacher</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEntries.map((entry) => (
                    <TableRow key={entry.id}>
                      <TableCell>
                        <Badge variant="outline">{DAYS[entry.day_of_week]}</Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        {formatTime(entry.start_time)} - {formatTime(entry.end_time)}
                      </TableCell>
                      <TableCell>{entry.class_name}</TableCell>
                      <TableCell>{entry.section_name || '-'}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{entry.subject_name}</Badge>
                      </TableCell>
                      <TableCell>{entry.teacher_name || '-'}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteEntry(entry.id)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}