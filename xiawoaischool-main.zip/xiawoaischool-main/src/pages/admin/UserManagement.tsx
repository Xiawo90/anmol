import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Search, UserPlus, CheckCircle, XCircle, Edit, Users, BookOpen, AlertCircle } from 'lucide-react';
import { Profile, AppRole } from '@/types';

interface UserWithDetails extends Profile {
  role?: AppRole;
  class_count?: number;
  class_names?: string[];
  enrollment_class?: string;
}

export default function UserManagement() {
  const { toast } = useToast();
  const [users, setUsers] = useState<UserWithDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [editingUser, setEditingUser] = useState<Profile | null>(null);
  const [editForm, setEditForm] = useState({ full_name: '', phone: '' });

  const fetchUsers = async () => {
    setLoading(true);
    try {
      // Fetch profiles
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (profilesError) throw profilesError;

      // Fetch roles
      const { data: roles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id, role');

      if (rolesError) throw rolesError;

      // Fetch teacher assignments for class counts
      const { data: teacherAssignments } = await supabase
        .from('teacher_assignments')
        .select('teacher_id, classes:class_id(name)');

      // Fetch student enrollments
      const { data: studentEnrollments } = await supabase
        .from('student_enrollments')
        .select('student_id, classes:class_id(name)');

      // Build teacher class map
      const teacherClassMap = new Map<string, string[]>();
      teacherAssignments?.forEach((ta: any) => {
        const className = ta.classes?.name;
        if (className) {
          const existing = teacherClassMap.get(ta.teacher_id) || [];
          if (!existing.includes(className)) {
            existing.push(className);
            teacherClassMap.set(ta.teacher_id, existing);
          }
        }
      });

      // Build student enrollment map
      const studentEnrollmentMap = new Map<string, string>();
      studentEnrollments?.forEach((se: any) => {
        if (se.classes?.name) {
          studentEnrollmentMap.set(se.student_id, se.classes.name);
        }
      });

      const usersWithRoles: UserWithDetails[] = (profiles || []).map(profile => {
        const userRole = roles?.find(r => r.user_id === profile.user_id)?.role as AppRole;
        const classNames = teacherClassMap.get(profile.user_id) || [];
        const enrollmentClass = studentEnrollmentMap.get(profile.user_id);
        
        return {
          ...profile,
          role: userRole,
          class_count: classNames.length,
          class_names: classNames,
          enrollment_class: enrollmentClass,
        };
      });

      setUsers(usersWithRoles);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast({ title: 'Error', description: 'Failed to fetch users', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleApprove = async (userId: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ approval_status: 'approved', is_active: true })
        .eq('user_id', userId);

      if (error) throw error;

      toast({ title: 'Success', description: 'User approved successfully' });
      fetchUsers();
    } catch (error) {
      console.error('Error approving user:', error);
      toast({ title: 'Error', description: 'Failed to approve user', variant: 'destructive' });
    }
  };

  const handleReject = async (userId: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ approval_status: 'rejected', is_active: false })
        .eq('user_id', userId);

      if (error) throw error;

      toast({ title: 'Success', description: 'User rejected' });
      fetchUsers();
    } catch (error) {
      console.error('Error rejecting user:', error);
      toast({ title: 'Error', description: 'Failed to reject user', variant: 'destructive' });
    }
  };

  const handleToggleActive = async (userId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_active: !currentStatus })
        .eq('user_id', userId);

      if (error) throw error;

      toast({ title: 'Success', description: `User ${currentStatus ? 'deactivated' : 'activated'}` });
      fetchUsers();
    } catch (error) {
      console.error('Error toggling user status:', error);
      toast({ title: 'Error', description: 'Failed to update user status', variant: 'destructive' });
    }
  };

  const handleEditSave = async () => {
    if (!editingUser) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ full_name: editForm.full_name, phone: editForm.phone })
        .eq('user_id', editingUser.user_id);

      if (error) throw error;

      toast({ title: 'Success', description: 'User updated successfully' });
      setEditingUser(null);
      fetchUsers();
    } catch (error) {
      console.error('Error updating user:', error);
      toast({ title: 'Error', description: 'Failed to update user', variant: 'destructive' });
    }
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    const matchesStatus = statusFilter === 'all' || 
      (statusFilter === 'pending' && user.approval_status === 'pending') ||
      (statusFilter === 'approved' && user.approval_status === 'approved') ||
      (statusFilter === 'rejected' && user.approval_status === 'rejected');
    return matchesSearch && matchesRole && matchesStatus;
  });

  const pendingCount = users.filter(u => u.approval_status === 'pending').length;
  const approvedTeachers = users.filter(u => u.role === 'teacher' && u.approval_status === 'approved');
  const teachersWithClasses = approvedTeachers.filter(t => (t.class_count || 0) > 0);
  const teachersWithoutClasses = approvedTeachers.filter(t => (t.class_count || 0) === 0);

  return (
    <DashboardLayout>
      <div className="space-responsive">
        <div className="flex-between-responsive">
          <div>
            <h1 className="page-title">User Management</h1>
            <p className="page-subtitle">Manage all users and their permissions</p>
          </div>
          {pendingCount > 0 && (
            <Badge variant="destructive" className="text-xs sm:text-sm px-2 sm:px-3 py-0.5 sm:py-1 self-start sm:self-auto">
              {pendingCount} Pending
            </Badge>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-2 sm:gap-3 md:gap-4">
          <Card>
            <CardContent className="p-3 sm:p-4">
              <div className="flex items-center gap-2 sm:gap-3">
                <Users className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-lg sm:text-2xl font-bold">{users.length}</p>
                  <p className="text-[10px] sm:text-sm text-muted-foreground truncate">Total Users</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 sm:p-4">
              <div className="flex items-center gap-2 sm:gap-3">
                <Users className="h-6 w-6 sm:h-8 sm:w-8 text-success flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-lg sm:text-2xl font-bold">{approvedTeachers.length}</p>
                  <p className="text-[10px] sm:text-sm text-muted-foreground truncate">Approved Teachers</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 sm:p-4">
              <div className="flex items-center gap-2 sm:gap-3">
                <BookOpen className="h-6 w-6 sm:h-8 sm:w-8 text-info flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-lg sm:text-2xl font-bold">{teachersWithClasses.length}</p>
                  <p className="text-[10px] sm:text-sm text-muted-foreground truncate">Teachers w/ Classes</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 sm:p-4">
              <div className="flex items-center gap-2 sm:gap-3">
                <Users className="h-6 w-6 sm:h-8 sm:w-8 text-info flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-lg sm:text-2xl font-bold">{users.filter(u => u.role === 'student').length}</p>
                  <p className="text-[10px] sm:text-sm text-muted-foreground truncate">Students</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 sm:p-4">
              <div className="flex items-center gap-2 sm:gap-3">
                <Users className="h-6 w-6 sm:h-8 sm:w-8 text-accent flex-shrink-0" />
                <div className="min-w-0">
                  <p className="text-lg sm:text-2xl font-bold">{users.filter(u => u.role === 'parent').length}</p>
                  <p className="text-[10px] sm:text-sm text-muted-foreground truncate">Parents</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Warning for teachers without classes */}
        {teachersWithoutClasses.length > 0 && (
          <Card className="border-warning bg-warning/5">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-warning flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-sm">Teachers without assigned classes</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {teachersWithoutClasses.length} approved teacher(s) have no classes assigned: {' '}
                    {teachersWithoutClasses.map(t => t.full_name).join(', ')}.
                    Go to Teacher Assignments to assign them.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Filters */}
        <Card>
          <CardContent className="p-3 sm:p-4">
            <div className="flex flex-col gap-3">
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or email..."
                  className="pl-10 text-sm"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
                <Select value={roleFilter} onValueChange={setRoleFilter}>
                  <SelectTrigger className="w-full sm:w-[140px] text-sm">
                    <SelectValue placeholder="Filter by role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="teacher">Teacher</SelectItem>
                    <SelectItem value="student">Student</SelectItem>
                    <SelectItem value="parent">Parent</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-full sm:w-[140px] text-sm">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Users Table */}
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead className="hidden sm:table-cell">Email</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead className="hidden md:table-cell">Class Info</TableHead>
                  <TableHead className="hidden lg:table-cell">Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      Loading users...
                    </TableCell>
                  </TableRow>
                ) : filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      No users found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium truncate max-w-[120px] sm:max-w-none">{user.full_name}</p>
                          <p className="text-[10px] text-muted-foreground sm:hidden truncate">{user.email}</p>
                        </div>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell">
                        <span className="truncate block max-w-[150px] md:max-w-none">{user.email}</span>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="capitalize text-[10px] sm:text-xs">
                          {user.role || 'No role'}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        {user.role === 'teacher' && user.approval_status === 'approved' && (
                          <div>
                            {user.class_count && user.class_count > 0 ? (
                              <Badge variant="secondary" className="text-xs">
                                {user.class_count} class(es)
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="text-xs text-warning border-warning">
                                No classes
                              </Badge>
                            )}
                          </div>
                        )}
                        {user.role === 'student' && (
                          <Badge variant="secondary" className="text-xs">
                            {user.enrollment_class || 'Not enrolled'}
                          </Badge>
                        )}
                        {user.role !== 'teacher' && user.role !== 'student' && (
                          <span className="text-muted-foreground text-xs">-</span>
                        )}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        <div className="flex gap-1">
                          <Badge
                            variant={
                              user.approval_status === 'approved' ? 'default' :
                              user.approval_status === 'pending' ? 'secondary' : 'destructive'
                            }
                            className="capitalize text-[10px] sm:text-xs"
                          >
                            {user.approval_status}
                          </Badge>
                          <Badge variant={user.is_active ? 'default' : 'secondary'} className="text-[10px] sm:text-xs">
                            {user.is_active ? 'Active' : 'Inactive'}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1 sm:gap-2">
                          {user.approval_status === 'pending' && (
                            <>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-success hover:text-success h-7 w-7 sm:h-8 sm:w-8 p-0"
                                onClick={() => handleApprove(user.user_id)}
                              >
                                <CheckCircle className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-destructive hover:text-destructive h-7 w-7 sm:h-8 sm:w-8 p-0"
                                onClick={() => handleReject(user.user_id)}
                              >
                                <XCircle className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                              </Button>
                            </>
                          )}
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-7 w-7 sm:h-8 sm:w-8 p-0"
                                onClick={() => {
                                  setEditingUser(user);
                                  setEditForm({ full_name: user.full_name, phone: user.phone || '' });
                                }}
                              >
                                <Edit className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-[90vw] sm:max-w-md">
                              <DialogHeader>
                                <DialogTitle className="text-lg">Edit User</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4 py-4">
                                <div className="space-y-2">
                                  <Label className="text-sm">Full Name</Label>
                                  <Input
                                    value={editForm.full_name}
                                    onChange={(e) => setEditForm({ ...editForm, full_name: e.target.value })}
                                    className="text-sm"
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label className="text-sm">Phone</Label>
                                  <Input
                                    value={editForm.phone}
                                    onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                                    className="text-sm"
                                  />
                                </div>
                                <Button onClick={handleEditSave} className="w-full">
                                  Save Changes
                                </Button>
                              </div>
                            </DialogContent>
                          </Dialog>
                          <Button
                            size="sm"
                            variant={user.is_active ? 'destructive' : 'default'}
                            onClick={() => handleToggleActive(user.user_id, user.is_active || false)}
                            className="hidden sm:inline-flex h-7 sm:h-8 text-xs px-2 sm:px-3"
                          >
                            {user.is_active ? 'Deactivate' : 'Activate'}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
