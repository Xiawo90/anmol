import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { format } from 'date-fns';
import { Plus, GraduationCap, Trash2, Users, AlertCircle, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { useTeacherAssignments } from '@/hooks/useTeacherAssignments';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface Exam {
  id: string;
  name: string;
  exam_date: string | null;
  total_marks: number;
  class_name: string;
  subject_name: string;
  results_count: number;
}

export default function TeacherExams() {
  const { user, isApproved } = useAuth();
  const { assignments: teacherClasses, isLoading: classesLoading, hasAssignments } = useTeacherAssignments();
  const [exams, setExams] = useState<Exam[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isResultsDialogOpen, setIsResultsDialogOpen] = useState(false);
  const [selectedExam, setSelectedExam] = useState<Exam | null>(null);
  const [students, setStudents] = useState<any[]>([]);
  const [results, setResults] = useState<Record<string, { marks: string; grade: string }>>({});
  const [formData, setFormData] = useState({
    name: '',
    exam_date: '',
    total_marks: '100',
    class_id: '',
  });

  useEffect(() => {
    if (user && isApproved) {
      fetchExams();
    }
  }, [user, isApproved]);

  const fetchExams = async () => {
    try {
      const { data, error } = await supabase
        .from('exams')
        .select(`
          id,
          name,
          exam_date,
          total_marks,
          class_id,
          subject_id,
          classes:class_id (name),
          subjects:subject_id (name)
        `)
        .eq('created_by', user?.id)
        .order('exam_date', { ascending: false });

      if (error) throw error;

      const examsWithCounts = await Promise.all(
        (data || []).map(async (exam: any) => {
          const { count } = await supabase
            .from('exam_results')
            .select('*', { count: 'exact', head: true })
            .eq('exam_id', exam.id);

          return {
            id: exam.id,
            name: exam.name,
            exam_date: exam.exam_date,
            total_marks: exam.total_marks || 100,
            class_name: exam.classes?.name || 'Unknown',
            subject_name: exam.subjects?.name || 'Unknown',
            results_count: count || 0,
          };
        })
      );

      setExams(examsWithCounts);
    } catch (error) {
      console.error('Error fetching exams:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const assignment = teacherClasses.find(c => c.id === formData.class_id);
      if (!assignment) return;

      const { error } = await supabase.from('exams').insert({
        name: formData.name,
        exam_date: formData.exam_date || null,
        total_marks: parseInt(formData.total_marks),
        class_id: assignment.class_id,
        subject_id: assignment.subject_id,
        created_by: user?.id,
      });

      if (error) throw error;

      toast.success('Exam created successfully');
      setIsDialogOpen(false);
      setFormData({
        name: '',
        exam_date: '',
        total_marks: '100',
        class_id: '',
      });
      fetchExams();
    } catch (error) {
      console.error('Error creating exam:', error);
      toast.error('Failed to create exam');
    }
  };

  const deleteExam = async (id: string) => {
    if (!confirm('Are you sure you want to delete this exam?')) return;

    try {
      const { error } = await supabase.from('exams').delete().eq('id', id);
      if (error) throw error;
      toast.success('Exam deleted');
      fetchExams();
    } catch (error) {
      console.error('Error deleting exam:', error);
      toast.error('Failed to delete exam');
    }
  };

  const openResultsDialog = async (exam: Exam) => {
    setSelectedExam(exam);
    setIsResultsDialogOpen(true);
    setStudents([]);
    setResults({});

    try {
      const { data: examData } = await supabase
        .from('exams')
        .select('class_id')
        .eq('id', exam.id)
        .single();

      if (!examData) return;

      // Fetch enrollments first
      const { data: enrollments, error: enrollError } = await supabase
        .from('student_enrollments')
        .select('student_id, roll_number')
        .eq('class_id', examData.class_id);

      if (enrollError) {
        console.error('Error fetching enrollments:', enrollError);
        return;
      }

      if (!enrollments || enrollments.length === 0) {
        return;
      }

      // Fetch profiles separately for enrolled students
      const studentIds = enrollments.map(e => e.student_id);
      const { data: profiles } = await supabase
        .from('profiles')
        .select('user_id, full_name')
        .in('user_id', studentIds);

      const profileMap = new Map((profiles || []).map(p => [p.user_id, p.full_name]));

      setStudents(enrollments.map((e: any) => ({
        id: e.student_id,
        name: profileMap.get(e.student_id) || 'Unknown',
        roll_number: e.roll_number,
      })));

      const { data: existingResults } = await supabase
        .from('exam_results')
        .select('student_id, marks_obtained, grade')
        .eq('exam_id', exam.id);

      const resultsMap: Record<string, { marks: string; grade: string }> = {};
      (existingResults || []).forEach((r: any) => {
        resultsMap[r.student_id] = {
          marks: r.marks_obtained?.toString() || '',
          grade: r.grade || '',
        };
      });

      setResults(resultsMap);
    } catch (error) {
      console.error('Error fetching students:', error);
    }
  };

  const updateResult = (studentId: string, field: 'marks' | 'grade', value: string) => {
    setResults(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        [field]: value,
      },
    }));
  };

  const saveResults = async () => {
    if (!selectedExam) return;

    try {
      await supabase.from('exam_results').delete().eq('exam_id', selectedExam.id);

      const records = students
        .filter(s => results[s.id]?.marks)
        .map(s => ({
          exam_id: selectedExam.id,
          student_id: s.id,
          marks_obtained: parseFloat(results[s.id].marks),
          grade: results[s.id].grade || null,
          entered_by: user?.id,
        }));

      if (records.length > 0) {
        const { error } = await supabase.from('exam_results').insert(records);
        if (error) throw error;
      }

      toast.success('Results saved');
      setIsResultsDialogOpen(false);
      fetchExams();
    } catch (error) {
      console.error('Error saving results:', error);
      toast.error('Failed to save results');
    }
  };

  if (!isApproved) {
    return (
      <DashboardLayout>
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">Your account is pending approval.</p>
          </CardContent>
        </Card>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-heading font-bold">Exams</h1>
            <p className="text-muted-foreground">Create exams and manage results</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button disabled={classesLoading || !hasAssignments}>
                <Plus className="mr-2 h-4 w-4" />
                Create Exam
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create New Exam</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="class">Class & Subject *</Label>
                  <Select
                    value={formData.class_id}
                    onValueChange={(value) => setFormData({ ...formData, class_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={classesLoading ? "Loading classes..." : "Select class"} />
                    </SelectTrigger>
                    <SelectContent>
                      {classesLoading ? (
                        <div className="flex items-center justify-center py-4">
                          <Loader2 className="h-4 w-4 animate-spin" />
                        </div>
                      ) : teacherClasses.length === 0 ? (
                        <div className="py-4 px-2 text-sm text-muted-foreground text-center">
                          No classes assigned
                        </div>
                      ) : (
                        teacherClasses.map((c) => (
                          <SelectItem key={c.id} value={c.id}>
                            {c.class_name} {c.section_name ? `- ${c.section_name}` : ''} ({c.subject_name})
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="name">Exam Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., Mid-term Exam"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="exam_date">Exam Date</Label>
                  <Input
                    id="exam_date"
                    type="date"
                    value={formData.exam_date}
                    onChange={(e) => setFormData({ ...formData, exam_date: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="total_marks">Total Marks *</Label>
                  <Input
                    id="total_marks"
                    type="number"
                    value={formData.total_marks}
                    onChange={(e) => setFormData({ ...formData, total_marks: e.target.value })}
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={!formData.class_id}>
                  Create Exam
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {!classesLoading && !hasAssignments && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>No Classes Assigned</AlertTitle>
            <AlertDescription>
              You don't have any classes assigned yet. Please contact an administrator to assign classes to you.
            </AlertDescription>
          </Alert>
        )}

        <Card>
          <CardHeader>
            <CardTitle>All Exams</CardTitle>
            <CardDescription>{exams.length} exams created</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8 text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin mr-2" />
                Loading...
              </div>
            ) : exams.length === 0 ? (
              <div className="text-center py-8">
                <GraduationCap className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No exams created yet.</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Exam Name</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Total Marks</TableHead>
                    <TableHead>Results</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {exams.map((exam) => (
                    <TableRow key={exam.id}>
                      <TableCell className="font-medium">{exam.name}</TableCell>
                      <TableCell>{exam.class_name}</TableCell>
                      <TableCell>{exam.subject_name}</TableCell>
                      <TableCell>
                        {exam.exam_date ? format(new Date(exam.exam_date), 'PP') : '-'}
                      </TableCell>
                      <TableCell>{exam.total_marks}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{exam.results_count} entered</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openResultsDialog(exam)}
                          >
                            <Users className="mr-1 h-4 w-4" />
                            Results
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteExam(exam.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Dialog open={isResultsDialogOpen} onOpenChange={setIsResultsDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Enter Results - {selectedExam?.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {students.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No students enrolled in this class.
                </div>
              ) : (
                <>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Roll No.</TableHead>
                        <TableHead>Student Name</TableHead>
                        <TableHead>Marks (/{selectedExam?.total_marks})</TableHead>
                        <TableHead>Grade</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {students.map((student) => (
                        <TableRow key={student.id}>
                          <TableCell>{student.roll_number || '-'}</TableCell>
                          <TableCell className="font-medium">{student.name}</TableCell>
                          <TableCell>
                            <Input
                              type="number"
                              max={selectedExam?.total_marks}
                              min={0}
                              className="w-20"
                              value={results[student.id]?.marks || ''}
                              onChange={(e) => updateResult(student.id, 'marks', e.target.value)}
                            />
                          </TableCell>
                          <TableCell>
                            <Input
                              className="w-16"
                              placeholder="A+"
                              value={results[student.id]?.grade || ''}
                              onChange={(e) => updateResult(student.id, 'grade', e.target.value)}
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  <Button onClick={saveResults} className="w-full">Save Results</Button>
                </>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}